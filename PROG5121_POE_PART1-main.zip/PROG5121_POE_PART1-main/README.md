# PROG5121_POE_PART1
Part 1 of the PROG5121 POE is a Java console app managing secure user registration and login. It validates formatting rules for usernames and phone numbers, enforces a robust password complexity wall, and securely stores profiles. The system's compliance is fully verified using an automated JUnit 4 test suite.
